<p><h4>Project managment Solution</h4><br />
Sulla base della collaborazione con un ampio gruppo di studi di consulenza tecnica professionale, offriamo una gamma completa di servizi per aiutare i nostri clienti a mantenere un vantaggio competitivo nei rispettivi mercati. Partendo da studi di fattibilit&agrave; e di pianificazione fino alle fasi operative e la manutenzione, personalizziamo i nostri servizi per soddisfare la vostra attivit&agrave; e gli obiettivi del progetto. La nostra rete globale di esperti tecnici lavora senza confini, la nostra filosofia offrire la soluzione migliore e pi&ugrave; economica .<br />
Un elenco rappresentativo dei nostri servizi:<br />
Servizi progettazione: Architettura / Ingegneria<br />
Architettura<br />
Ingegneria civile<br />
Ingegneria Elettrico / Meccanica<br />
Protezione antincendio / sicurezza<br />
Ingegneria industriale<br />
Interior design<br />
Industria meccanica<br />
Ingegneria di processo<br />
Ingegneria strutturale<br />
Ingegneria dei trasporti</p>

<p><h4>Servizi operatici: Costruzione</h4><br />
Avviamento e messa in servizio<br />
Gestione delle Costruzioni<br />
Selezione dei subappalti<br />
Spedizioni<br />
General Contractor<br />
Gestione della Manutenzione<br />
Acquisti<br />
Ristrutturazioni<br />
Approvazioni</p>

<p><h4>Servizi Ambientali, salute e sicurezza</h4><br />
Gestione della qualit&agrave; dell'aria<br />
Gestione Pratiche di Rispetto ambientale / autorizzazioni<br />
Indagini ambientali e analisi<br />
Ingegneria ambientale<br />
Processo di gestione della sicurezza / HAZOP<br />
Progettazione Correttiva e costruzione<br />
Progettazione e Gestione della Sicurezza<br />
Gestione dei rifiuti solidi e pericolosi<br />
Gestione della qualit&agrave; dell&rsquo;acqua</p>

<p><h4>Pianificazione</h4> <br />
Progettazione concettuale<br />
Analisi economica<br />
Servizi di pianificazione<br />
Studi di fattibilit&agrave;<br />
Pianificazione interattiva<br />
Valutazione dei permessi<br />
Programmazione<br />
Pianificazione coordinata<br />
Selezione del sito<br />
Valutazione di tecnologie</p>

<p><h4>Servizi di gestione</h4><br />
Budgeting<br />
Consulenza<br />
Stima dei costi / gestione<br />
Stima dei lavori<br />
EPC (Ingegneria / Acquisti / Costruzione)<br />
Gestione dei materiali<br />
Project Financing<br />
Gestione del progetto<br />
Garanzia della qualit&agrave; / controllo della qualit&agrave;<br />
Programmazione<br />
</p>