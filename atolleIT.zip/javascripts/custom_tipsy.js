// Style for jQuery Tipsy

  $(function() {
    $('.socialfade').tipsy();
  });

  $(function() {
    $('.navlinks').tipsy();
  });

  $(function() {
    $('.socialicons').tipsy();
  });