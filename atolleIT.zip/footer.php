<div class="sixteen columns sepline">
	<p class="three column alpha socialized">
		<a href="#"><img class="socialicons" title="<?php echo $social[0]; ?>" src="images/glyfacebook.png"/></a>
		<a href="#"><img class="socialicons" title="<?php echo $social[1]; ?>" src="images/glytwitter.png"/></a>
		<a href="#"><img class="socialicons" title="<?php echo $social[2]; ?>" src="images/glylinked.png"/></a>
	</p>
	<div class="offset-by-eleven">
		<p class="copyrightcol five columns omega">&copy; 2012<span id="year_now"></span> Atolle. <?php echo $copyRight;?></p>
	</div>
</div>