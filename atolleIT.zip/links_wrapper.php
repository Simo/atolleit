<div  class="page wrapper">    
        <!-- slider code start -->
          <div class="row clearfix">
            <div class="col span_6 fwImage">
              <div id="video-gallery" class="royalSlider videoGallery rsDefault">
                 <a class="rsImg" data-rsVideo="https://vimeo.com/45830194" href="http://flickholdr.com/655/410/sun">
                  <div class="rsTmb">
                    <h5>Atolle s.a.r.l.</h5>
                    <p>partner</p>
                  </div>
                </a>
                <div class="rsContent">
                  <a class="rsImg" data-rsVideo="http://flickholdr.com/655/410/bw" href="http://flickholdr.com/655/415/bw">
                    <div class="rsTmb">
                      <h5>Giuman</h5>
                      <p>supplier</p>
                    </div>
                  </a>
                  <h3 class="rsABlock sampleBlock"><a class="collegamento" href="http://apps.baskettiamo.it">GO ></a></h3>
                </div>
                <div class="rsContent">
                 <a class="rsImg" data-rsVideo="https://vimeo.com/44878206" href="http://flickholdr.com/655/415/picasso">
                  <div class="rsTmb">
                    <h5>Atolle Italia</h5>
                    <p>competitor</p>
                  </div>
                </a>
                <h3 class="rsABlock sampleBlock"><a class="collegamento" href="http://apps.baskettiamo.it">GO ></a></h3>
                </div>
                <a class="rsImg" data-rsVideo="https://vimeo.com/45778774" href="http://flickholdr.com/655/415/space">
                  <div class="rsTmb">
                    <h5>Enelca</h5>
                    <p>leasing candidate</p>
                  </div>
                </a>
                 <a class="rsImg" data-rsVideo="https://vimeo.com/41132461" href="http://flickholdr.com/655/415/summer">
                  <div class="rsTmb">
                    <h5>Google.com</h5>
                    <p>motore di ricerca</p>
                  </div>
                </a>
               <a class="rsImg" data-rsVideo="hhttps://vimeo.com/44388232" href="http://flickholdr.com/655/415/frisco">
                  <div class="rsTmb">
                    <h5>Amazon</h5>
                    <p>book seller</p>
                  </div>
                </a>
                <a class="rsImg" data-rsVideo="http://www.youtube.com/watch?v=VDspPKDMBMo" href="http://flickholdr.com/655/415/snow">
                  <div class="rsTmb">
                    <h5>Any Other link</h5>
                    <p>by guess who?</p>
                  </div>
                </a>
              </div>
           
          </div> <!-- chiude span6-->
          </div>
      </div>